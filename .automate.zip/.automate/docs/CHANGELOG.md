v0.2: adopt .automate/ + AUTOMATE_ prefixes; keep legacy SR_/AUTOMATER_ compat.
