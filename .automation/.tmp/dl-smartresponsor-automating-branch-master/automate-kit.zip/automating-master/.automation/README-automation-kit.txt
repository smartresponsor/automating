See README.md (component scope lock + usage + API).
